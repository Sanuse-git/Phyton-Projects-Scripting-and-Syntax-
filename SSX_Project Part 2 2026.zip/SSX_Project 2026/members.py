import sqlite3

def add_member(name, membership_id, contact, membership_type):
    conn = sqlite3.connect("library.db")
    cursor = conn.cursor()
    cursor.execute("INSERT INTO Members (name, membership_id, contact, membership_type) VALUES (?, ?, ?, ?)",
                   (name, membership_id, contact, membership_type))
    conn.commit()
    conn.close()

def get_members():
    conn = sqlite3.connect("library.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Members")
    rows = cursor.fetchall()
    conn.close()
    return rows

def delete_member(member_id):
    conn = sqlite3.connect("library.db")
    cursor = conn.cursor()
    cursor.execute("DELETE FROM Members WHERE id=?", (member_id,))
    conn.commit()
    conn.close()