import sqlite3

def add_book(title, author, isbn, genre, status):
    conn = sqlite3.connect("library.db")
    cursor = conn.cursor()
    cursor.execute("INSERT INTO Books (title, author, isbn, genre, status) VALUES (?, ?, ?, ?, ?)",
                   (title, author, isbn, genre, status))
    conn.commit()
    conn.close()

def get_books():
    conn = sqlite3.connect("library.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Books")
    rows = cursor.fetchall()
    conn.close()
    return rows

def delete_book(book_id):
    conn = sqlite3.connect("library.db")
    cursor = conn.cursor()
    cursor.execute("DELETE FROM Books WHERE id=?", (book_id,))
    conn.commit()
    conn.close()