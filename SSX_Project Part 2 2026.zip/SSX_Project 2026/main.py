# =========================
# database.py
# =========================
import sqlite3

def connect():
    conn = sqlite3.connect("library.db")
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS Books (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        author TEXT,
        isbn TEXT UNIQUE,
        genre TEXT,
        status TEXT
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS Members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        membership_id TEXT UNIQUE,
        contact TEXT,
        membership_type TEXT
    )
    """)

    conn.commit()
    conn.close()

# =========================
# books.py
# =========================
import sqlite3

def add_book(title, author, isbn, genre, status):
    conn = sqlite3.connect("library.db")
    cursor = conn.cursor()
    cursor.execute("INSERT INTO Books (title, author, isbn, genre, status) VALUES (?, ?, ?, ?, ?)",
                   (title, author, isbn, genre, status))
    conn.commit()
    conn.close()


def get_books():
    conn = sqlite3.connect("library.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Books")
    rows = cursor.fetchall()
    conn.close()
    return rows


def delete_book(book_id):
    conn = sqlite3.connect("library.db")
    cursor = conn.cursor()
    cursor.execute("DELETE FROM Books WHERE id=?", (book_id,))
    conn.commit()
    conn.close()

# =========================
# members.py
# =========================
import sqlite3

def add_member(name, membership_id, contact, membership_type):
    conn = sqlite3.connect("library.db")
    cursor = conn.cursor()
    cursor.execute("INSERT INTO Members (name, membership_id, contact, membership_type) VALUES (?, ?, ?, ?)",
                   (name, membership_id, contact, membership_type))
    conn.commit()
    conn.close()


def get_members():
    conn = sqlite3.connect("library.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Members")
    rows = cursor.fetchall()
    conn.close()
    return rows


def delete_member(member_id):
    conn = sqlite3.connect("library.db")
    cursor = conn.cursor()
    cursor.execute("DELETE FROM Members WHERE id=?", (member_id,))
    conn.commit()
    conn.close()

# =========================
# main.py
# =========================
from tkinter import *
from tkinter import messagebox
import database
import books
import members

# Initialize DB
database.connect()

root = Tk()
root.title("Library Management System")
root.geometry("400x300")

# =========================
# BOOK WINDOW
# =========================

def open_books():
    win = Toplevel(root)
    win.title("Books")

    Label(win, text="Title").grid(row=0, column=0)
    Label(win, text="Author").grid(row=1, column=0)
    Label(win, text="ISBN").grid(row=2, column=0)
    Label(win, text="Genre").grid(row=3, column=0)
    Label(win, text="Status").grid(row=4, column=0)

    title = Entry(win)
    author = Entry(win)
    isbn = Entry(win)
    genre = Entry(win)
    status = Entry(win)

    title.grid(row=0, column=1)
    author.grid(row=1, column=1)
    isbn.grid(row=2, column=1)
    genre.grid(row=3, column=1)
    status.grid(row=4, column=1)

    listbox = Listbox(win, width=50)
    listbox.grid(row=6, column=0, columnspan=2)

    def add():
        try:
            books.add_book(title.get(), author.get(), isbn.get(), genre.get(), status.get())
            messagebox.showinfo("Success", "Book Added")
        except:
            messagebox.showerror("Error", "ISBN must be unique")

    def view():
        listbox.delete(0, END)
        for row in books.get_books():
            listbox.insert(END, row)

    def delete():
        selected = listbox.get(ACTIVE)
        books.delete_book(selected[0])
        view()

    Button(win, text="Add", command=add).grid(row=5, column=0)
    Button(win, text="View", command=view).grid(row=5, column=1)
    Button(win, text="Delete", command=delete).grid(row=7, column=0)

# =========================
# MEMBER WINDOW
# =========================

def open_members():
    win = Toplevel(root)
    win.title("Members")

    Label(win, text="Name").grid(row=0, column=0)
    Label(win, text="Membership ID").grid(row=1, column=0)
    Label(win, text="Contact").grid(row=2, column=0)
    Label(win, text="Type").grid(row=3, column=0)

    name = Entry(win)
    mem_id = Entry(win)
    contact = Entry(win)
    mtype = Entry(win)

    name.grid(row=0, column=1)
    mem_id.grid(row=1, column=1)
    contact.grid(row=2, column=1)
    mtype.grid(row=3, column=1)

    listbox = Listbox(win, width=50)
    listbox.grid(row=6, column=0, columnspan=2)

    def add():
        try:
            members.add_member(name.get(), mem_id.get(), contact.get(), mtype.get())
            messagebox.showinfo("Success", "Member Added")
        except:
            messagebox.showerror("Error", "Membership ID must be unique")

    def view():
        listbox.delete(0, END)
        for row in members.get_members():
            listbox.insert(END, row)

    def delete():
        selected = listbox.get(ACTIVE)
        members.delete_member(selected[0])
        view()

    Button(win, text="Add", command=add).grid(row=5, column=0)
    Button(win, text="View", command=view).grid(row=5, column=1)
    Button(win, text="Delete", command=delete).grid(row=7, column=0)

# =========================
# MAIN MENU
# =========================

Label(root, text="Library System", font=("Arial", 16)).pack(pady=20)

Button(root, text="Manage Books", width=20, command=open_books).pack(pady=10)
Button(root, text="Manage Members", width=20, command=open_members).pack(pady=10)
Button(root, text="Exit", width=20, command=root.quit).pack(pady=10)

root.mainloop()
