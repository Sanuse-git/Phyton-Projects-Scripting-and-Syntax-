# ==========================================
# SQLite GUI Store Application
# Car Parts Store Management System
# Beginner Friendly - PyCharm
# ==========================================

# Import required libraries
import sqlite3
from tkinter import *
from tkinter import messagebox



# This one will  connect to SQLite database It creates db if one dont exist
conn = sqlite3.connect("StoreDB.db")
cursor = conn.cursor()

#  Here we create a Parts table
cursor.execute("""
CREATE TABLE IF NOT EXISTS Parts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    partname TEXT,
    customer TEXT,
    retailer TEXT,
    price TEXT
)
""")
conn.commit()

# This one will insert sample record only if table is empty
cursor.execute("SELECT COUNT(*) FROM Parts")
count = cursor.fetchone()[0]

if count == 0:
    sample_data = [
        ("Brake Pads", "John", "AutoZone", "450"),
        ("Oil Filter", "Mike", "Midas", "120"),
        ("Spark Plug", "Sarah", "Bosch", "80")
    ]

    cursor.executemany("""
    INSERT INTO Parts (partname, customer, retailer, price)
    VALUES (?, ?, ?, ?)
    """, sample_data)

    conn.commit()


# This  Function fetches all parts from database
def fetch_parts():
    listbox.delete(0, END)
    cursor.execute("SELECT * FROM Parts")
    rows = cursor.fetchall()

    for row in rows:
        listbox.insert(END, row)


# This  Function will  add a new part
def add_part():
    if partname_entry.get() == "" or customer_entry.get() == "":
        messagebox.showerror("Error", "Please fill in required fields")
        return

    cursor.execute("""
    INSERT INTO Parts (partname, customer, retailer, price)
    VALUES (?, ?, ?, ?)
    """, (
        partname_entry.get(),
        customer_entry.get(),
        retailer_entry.get(),
        price_entry.get()
    ))
    conn.commit()

    messagebox.showinfo("Success", "Part added successfully")
    clear_fields()
    fetch_parts()


#This Function Will update selected part
def update_part():
    selected = listbox.curselection()

    if not selected:
        messagebox.showerror("Error", "Please select a part to update")
        return

    part_id = listbox.get(selected)[0]

    cursor.execute("""
    UPDATE Parts
    SET partname=?, customer=?, retailer=?, price=?
    WHERE id=?
    """, (
        partname_entry.get(),
        customer_entry.get(),
        retailer_entry.get(),
        price_entry.get(),
        part_id
    ))
    conn.commit()

    messagebox.showinfo("Success", "Part updated successfully")
    clear_fields()
    fetch_parts()


# This Function  deletes selected part
def delete_part():
    selected = listbox.curselection()

    if not selected:
        messagebox.showerror("Error", "Please select a part to delete")
        return

    part_id = listbox.get(selected)[0]

    cursor.execute("DELETE FROM Parts WHERE id=?", (part_id,))
    conn.commit()

    messagebox.showinfo("Success", "Part deleted successfully")
    clear_fields()
    fetch_parts()


# Function to clear text fields
def clear_fields():
    partname_entry.delete(0, END)
    customer_entry.delete(0, END)
    retailer_entry.delete(0, END)
    price_entry.delete(0, END)


# Function to load selected record into textboxes
def load_selected(event):
    selected = listbox.curselection()

    if not selected:
        return

    row = listbox.get(selected)

    clear_fields()

    partname_entry.insert(0, row[1])
    customer_entry.insert(0, row[2])
    retailer_entry.insert(0, row[3])
    price_entry.insert(0, row[4])


# ==========================================
# GUI SETUP
# ==========================================

root = Tk()
root.title("Car Parts Store Application")
root.geometry("700x500")
root.config(bg="lightblue")

# Labels
Label(root, text="Part Name", bg="lightblue", font=("Arial", 12)).place(x=20, y=20)
Label(root, text="Customer", bg="lightblue", font=("Arial", 12)).place(x=20, y=60)
Label(root, text="Retailer", bg="lightblue", font=("Arial", 12)).place(x=20, y=100)
Label(root, text="Price", bg="lightblue", font=("Arial", 12)).place(x=20, y=140)

# Entry boxes
partname_entry = Entry(root, width=30)
partname_entry.place(x=150, y=20)

customer_entry = Entry(root, width=30)
customer_entry.place(x=150, y=60)

retailer_entry = Entry(root, width=30)
retailer_entry.place(x=150, y=100)

price_entry = Entry(root, width=30)
price_entry.place(x=150, y=140)

# Buttons
Button(root, text="Add Part", width=15, command=add_part).place(x=20, y=200)
Button(root, text="Update Part", width=15, command=update_part).place(x=180, y=200)
Button(root, text="Delete Part", width=15, command=delete_part).place(x=340, y=200)
Button(root, text="Clear", width=15, command=clear_fields).place(x=500, y=200)
Button(root, text="Reload Parts", width=15, command=fetch_parts).place(x=260, y=250)

# Listbox to display parts
listbox = Listbox(root, width=90, height=12)
listbox.place(x=20, y=300)

# Bind listbox selection
listbox.bind("<<ListboxSelect>>", load_selected)

# Load parts when app starts
fetch_parts()

# Run GUI
root.mainloop()

# Close database connection after window closes
conn.close()

